document.addEventListener("DOMContentLoaded", function () {
    const muteButton = document.getElementById('mute-button');
    const backgroundMusic = document.getElementById('background-music');
    let isMuted = false;

    muteButton.addEventListener('click', function () {
        if (isMuted) {
            backgroundMusic.muted = false;
            muteButton.textContent = '🔊';
        } else {
            backgroundMusic.muted = true;
            muteButton.textContent = '🔇';
        }
        isMuted = !isMuted;
    });

    // Staff team data
    const staffMembers = [
        { name: 'John Doe', role: 'Server Admin' },
        { name: 'Jane Smith', role: 'Moderator' },
        { name: 'Sam Brown', role: 'Developer' },
        { name: 'Lisa White', role: 'Community Manager' }
    ];

    const staffList = document.getElementById('staff-list');

    // Dynamically add staff members to the page
    staffMembers.forEach(member => {
        const staffDiv = document.createElement('div');
        staffDiv.classList.add('staff-member');
        staffDiv.innerHTML = `<strong>${member.name}</strong><br>${member.role}`;
        staffList.appendChild(staffDiv);
    });
});
