fx_version 'cerulean'
game 'gta5'

author 'MrYorkshireTea Modifications'
description 'A simple and stylish FiveM loading screen'
version '1.0.0'

files {
    'index.html',
    'style.css',
    'script.js',
    'background.mp4',
    'background-music.mp3',
    'logo.png'
}

loadscreen 'index.html'
